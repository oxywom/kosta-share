public interface ILatte {
	void changeMilk(String milk);
}
