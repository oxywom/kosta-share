public class Ade extends EtcBeverage {
	public Ade(int price) {
		super(price, true);
	}

	@Override
	String getName() {
		return "에이드";
	}
}
