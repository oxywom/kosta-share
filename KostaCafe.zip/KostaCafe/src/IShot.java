public interface IShot {
	int SHOT_PRICE=500;
	void addShot(int cnt);
}
