package com.kosta;

public class MyClass {

}
