import pac.ATest;

public class ETest extends ATest {
	void method3() {
		System.out.println(n);
	}
}
