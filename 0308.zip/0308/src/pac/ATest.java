package pac;
public class ATest {
	protected int n;
	public int m;
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	
	public ATest(){}
	ATest(int n) {}
	
	void method() {}
	public void method2() {}
	
}
