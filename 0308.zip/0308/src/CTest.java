class DTest {
	private int n;
	int m;
	
	void method() {
		n=10;
	}
}

public class CTest {
	CTest() {}
	private CTest(int n) {}
}
