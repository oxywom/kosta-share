package com.kosta.emp;

public interface IBusinessTrip {
	void goBusinessTrip(int day);
}
