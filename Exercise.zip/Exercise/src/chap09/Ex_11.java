package chap09;

public class Ex_11 {

	public static void main(String[] args) throws Exception {
		try {
			if(args.length!=2) throw new Exception("시작단, 끝단 두 개의 정수를 입력하세요");
			int from = Integer.parseInt(args[0]);
			int to = Integer.parseInt(args[1]);
			if(!(from>=2 && from<=9) || !(to>=2 && to<=9)) {
				throw new Exception("단의 범위는 2와 9사이의 값이여야 합니다.");
			}
			if(from>to) {
				int dan=from;
				from=to;
				to=dan;
			}
			
			for(int dan=from; dan<=to; dan++) {
				for(int i=1; i<=9; i++) {
					System.out.println(dan+"*"+i+"="+dan*i);
				}
				System.out.println();
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

}
