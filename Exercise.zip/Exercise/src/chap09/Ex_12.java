package chap09;

public class Ex_12 {

	public static int getRand(int from, int to) { //from:1, to:10, from:2,to:4
		//0*10+1<= Math.random()*10+1 <1*10+1    : 1<=   <=10		
		//0*10+1<= Math.random()*(to-from+1)+from <1*10+1    : 1<=   <=10	
		//0*(4-2+1)+2 <= Math.ramdom()*(4-2+1)+2 < 1*(4-2+1)+2
		
		return (int)(Math.random()*(Math.abs(to-from)+1))+Math.min(from, to);
		
	}
	public static void main(String[] args) {
		for(int i=0; i< 20; i++)
			System.out.print(getRand(5,0)+",");

	}
}
