package chap08;

class Parent {
	Parent() {}
	Parent(int n) {}
}

class Child extends Parent {
	Child() {
		//super(10);
	}
}

class UnsupportedFuctionException extends RuntimeException {
	final private int ERR_CODE;
	
	public UnsupportedFuctionException(String message, int code) {
		super(message);
		ERR_CODE = code;
	}
	
	public int getErrorCode() {
		return ERR_CODE;
	}
	
	@Override
	public String getMessage() {
		return "["+ERR_CODE+"]"+super.getMessage();
	}
}

public class Ex_09 {

	public static void main(String[] args) throws Exception {
		throw new UnsupportedFuctionException("지원하지 않는 기능입니다.",100);
	}

}
