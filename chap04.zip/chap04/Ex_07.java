package chap04;

public class Ex_07 {

	public static void main(String[] args) {
		int value = (int) (Math.random() * 6) + 1;
		System.out.println("value:" + value);

	}

}
