
public class ExceptionTest3 {

	static void method1() throws Exception {
		String str = null;
		try {
			System.out.println(str.toString());
		} catch(NullPointerException e) {
			System.out.println("1차 예외 처리");
			throw new Exception("2차 예외 처리");
		}
	}
	public static void main(String[] args) {
		try {
			method1();
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("종료");
	}
}
