public class StringTest1 {
	public static void main(String[] args) {
		int n=10;
		String str1 = "John";
		String str2 = "John";
		System.out.println(str1==str2);
		
		char[] carr = {'J','o','h','n'};
		StringBuffer sb = new StringBuffer("John");
		
		String str3 = new String(str1);  //String(String)
		String str4 = new String(carr);  //String(char[])
		String str5 = new String(sb);    //String(StringBuffer)
		
		System.out.println(str3==str4);
		System.out.println(str3);
		System.out.println(str4);
		System.out.println(str5);
		
		//charAt
		char h = str1.charAt(2);
		for(int i=0; i<str1.length(); i++) {
			System.out.print(str1.charAt(i));
		}
		System.out.println();
		//concat
		String info = str1.concat(":25");
		System.out.println(info);
		System.out.println(str1);
		
		//contains
		System.out.println(info.contains(":"));
		
		//endsWith
		String filename="news.txt";
		System.out.println(filename.endsWith("txt"));
		String name="홍기동";
		System.out.println(name.endsWith("동"));
		
		//equals
		String name1=new String("홍길동");
		String name2=new String("홍길동");
		System.out.println(name1==name2);  //false
		System.out.println(name1.equals(name2));  //true
		
		//equalsIgnoreCase
		String alph1=new String("ABC");
		String alph2=new String("abc");
		System.out.println(alph1.equals(alph2));
		System.out.println(alph1.equalsIgnoreCase(alph2));
		
		//indexOf
		String grace="How are you?";
		System.out.println(grace.indexOf('a'));
		System.out.println(grace.indexOf('!'));
		System.out.println(grace.indexOf("you"));
		String haha="hahaha";
		System.out.println(haha.indexOf('h', 1));
		System.out.println(haha.indexOf("ha", 1));
		
		//replace
		String tata=haha.replace('h', 't');
		System.out.println(tata);
		System.out.println(haha);  //원본은 바뀌지 않는다.
		String momo=haha.replace("ha", "mo");
		System.out.println(momo);
		
		//replaceFirst
		String fha = haha.replaceFirst("ha", "mo");
		System.out.println(fha);
		
		//split
		String fruitstr="banana#apple#melon#strawberry";
		String[] fruits = fruitstr.split("#");
		for(int i=0; i<fruits.length; i++) {
			System.out.println(fruits[i]);
		}
		
		//substring
		//String grace="How are you?";
		String are = grace.substring(4, 7);
		System.out.println(are);
		String are2 = grace.substring(4);
		System.out.println(are2);
		
		//toLowerCase
		String lower = "ABCDE";
		System.out.println(lower.toLowerCase());
		
		//toUpperCase
		String upper = "abcde";
		System.out.println(upper.toUpperCase());
		
		//trim  : 문자열의 앞뒤 스페이스 제거
		String tstr = "   How are you   ";
		System.out.println(tstr);
		System.out.println(tstr.trim());
		
		String s100 = String.valueOf(100);
		String strue = String.valueOf(true);
		String sf100 = String.valueOf(100f);
		
		String s100_2 = 100+"";
		String strue_2 = true+"";
		String sf100_2 = 100f+"";
		
		int n100 = Integer.parseInt("100");
		float f = Float.parseFloat("100.3");
		double d = Double.parseDouble("3.14");
	}
}
