public class Account {
	String id;
	String name;
	int balance;
	
	Account(String id, String name, int balance) {
		this.id=id;
		this.name=name;
		this.balance=balance;
	}
	
	String info() {
		return "계좌번호:"+id+", 이름:"+name+", 잔액:"+balance;
	}
	
	void deposit(int money) {
		balance += money;
	}
	
	void withdraw(int money) {
		if(balance>=money)
			balance -= money;
	}
}
