package exc;

public enum BANK_ERR {
	NOT_ID,DOUBLE_ID,WITHDRAW,DEPOSIT,MENU,ACC_MENU
}
