package acc;

import exc.BANK_ERR;
import exc.BankException;

public class Account {
	String id;
	String name;
	int balance;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Account(String id, String name, int balance) {
		this.id=id;
		this.name=name;
		this.balance=balance;
	}
	
	public String info() {
		return "계좌번호:"+id+", 이름:"+name+", 잔액:"+balance;
	}
	
	public void deposit(int money) throws BankException {
		if(money<=0) {
			throw new BankException("입금오류", BANK_ERR.DEPOSIT);
		}
		balance += money;
	}
	
	public void withdraw(int money) throws BankException {
		if(balance<money) {
			throw new BankException("출금오류", BANK_ERR.WITHDRAW);
		}
		balance -= money;
	}
}
