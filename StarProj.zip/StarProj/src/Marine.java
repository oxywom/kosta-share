public class Marine extends GroundUint {
	public Marine() {
		super(40);
		hitPoint = MAX_HP;
	}
	
	@Override
	public String toString() {
		return "Marine";
	}
}
