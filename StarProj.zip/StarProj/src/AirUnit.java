public class AirUnit extends Unit {
	public AirUnit(int hp) {
		super(hp);
	}
}
