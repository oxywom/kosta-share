public class GroundUint extends Unit {
	public GroundUint(int hp) {
		super(hp);
	}
}
