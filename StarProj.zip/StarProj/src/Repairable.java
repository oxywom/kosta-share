public interface Repairable {

}
