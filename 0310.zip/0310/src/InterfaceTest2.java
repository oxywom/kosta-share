//class Button {
//	public void onClick() {
//		System.out.println("버튼이 눌림");
//	}
//}
//
//class LoginButton extends Button {
//	@Override
//	public void onClick() {
//		super.onClick();
//		System.out.println("로그인 처리");
//	}
//}


public class InterfaceTest2 {
	public static void main(String[] args) {
//		Button button = new Button();
//		button.onClick();
//		
//		LoginButton loginBtn = new LoginButton();
//		loginBtn.onClick();
	}
}
