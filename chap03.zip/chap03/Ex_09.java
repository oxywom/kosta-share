package chap03;

public class Ex_09 {

	public static void main(String[] args) {
		char ch = 'z';
		boolean b = ('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z');
		System.out.println(b);
	}

}
