package chap03;

public class Ex_05 {

	public static void main(String[] args) {
		int num = 333;
		System.out.println(num / 10 * 10 + 1);

	}

}
