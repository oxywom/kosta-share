package chap03;

public class Ex_06 {

	public static void main(String[] args) {
		int num = 24;
		System.out.println(10 - num % 10);
	}

}
