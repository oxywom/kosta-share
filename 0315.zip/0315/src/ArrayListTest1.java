import java.util.ArrayList;

public class ArrayListTest1 {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		
		Object obj1 = new Integer(10);
		
		Object obj2 = 20; //boxing
		int n = (int)obj2; //unboxing
		
		//add
		al.add(10);
		al.add(20);
		al.add(30);

		//get
		for(int i=0; i<al.size(); i++) {
			System.out.println(al.get(i));
		}
		
		for(Object data : al) {  //향상된 for문
			System.out.println(data);
		}	
	}
}
