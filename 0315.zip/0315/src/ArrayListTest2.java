import java.util.ArrayList;

class Person {
	int age;
	String name;
	Person(String name, int age) {
		this.name=name;
		this.age=age;
	}
	
	String info() {
		return name+","+age;
	}
}
public class ArrayListTest2 {

	public static void main(String[] args) {
		ArrayList<Person> alist = new ArrayList<Person>();
		alist.add(new Person("hong",20));
		alist.add(new Person("song",25));
		alist.add(new Person("hang",30));
		
		for(Person p : alist) {
			System.out.println(p.info());
		}
		
		String[] arr = new String[10];
		arr[0] = "orange";
		arr[1] = "banana";
		
		for(String s : arr) {
			System.out.println(s);
		}
		
//		String[] sarr = {"apple", "banana","orange" };
//		for(String s : sarr) {
//			System.out.println(s);
//		}
	}
}
