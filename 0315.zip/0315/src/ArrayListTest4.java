import java.util.ArrayList;

public class ArrayListTest4 {

	public static void printInfo(Person[] pers) {
		for(Person p : pers) {
			System.out.println(p.info());
		}
	}
	
	public static void main(String[] args) {
		ArrayList<Person> pers = new ArrayList<>();
		pers.add(new Person("홍길동",20));
		pers.add(new Person("고길동",25));
		pers.add(new Person("장길동",30));

		Person[] parr = new Person[pers.size()];
		pers.toArray(parr);
		printInfo(parr);
	}

}
